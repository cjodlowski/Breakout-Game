var searchData=
[
  ['ui',['UI',['../classUI.html',1,'UI'],['../classUI.html#a3ef5060ba7082f6dcdb9332397d87287',1,'UI::UI()']]],
  ['update',['Update',['../classBall.html#af6db0c50a2974beb4c27cb29c9a0e2df',1,'Ball::Update()'],['../classBoard.html#aa1fb89db8206ace3f973f2f911af4125',1,'Board::Update()'],['../classEntity.html#aec10420b2cfc1b9a367d018966c620d3',1,'Entity::Update()'],['../classPaddle.html#a8a3aa86f567315423f92ecfb5fd3b6f5',1,'Paddle::Update()'],['../classUI.html#ae81d8cfea9390f62e42c47a440bf4951',1,'UI::Update()']]]
];
