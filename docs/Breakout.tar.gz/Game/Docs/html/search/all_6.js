var searchData=
[
  ['render',['Render',['../classBall.html#aad08ffaea46f61b5ba55b35caf3f8085',1,'Ball::Render()'],['../classBoard.html#adf586f328ba9c106ec171543bb2745cf',1,'Board::Render()'],['../classEntity.html#a3ccb865beca0ae97482f4fe756f62d12',1,'Entity::Render()'],['../classPaddle.html#a028df821bb4ecd16c59cadb55e5f89ba',1,'Paddle::Render()'],['../classUI.html#a6a37a366a7845d18acf9cf1c24128032',1,'UI::Render()']]],
  ['run',['Run',['../classGame.html#a96341ca5b54d90adc3ecb3bf0bcd2312',1,'Game']]]
];
