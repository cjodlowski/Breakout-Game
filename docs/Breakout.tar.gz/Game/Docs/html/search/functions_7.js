var searchData=
[
  ['setdirection',['SetDirection',['../classBall.html#a926a05c08b97fe1e294d100118e89761',1,'Ball::SetDirection()'],['../classPaddle.html#ac168c216a591b78851142d2160cebf9b',1,'Paddle::SetDirection()']]],
  ['settext',['SetText',['../classUI.html#a8835453038f03432fdbe4707684282fd',1,'UI']]]
];
