var searchData=
[
  ['collides',['Collides',['../classEntity.html#aedb02f3a7501604c34cb58b796873ff8',1,'Entity']]],
  ['createlevel',['CreateLevel',['../classBoard.html#af11cf454515ef90de6c659a79bcbac00',1,'Board::CreateLevel()'],['../classBoard.html#a924c91faad6786012d6ab8d5c5213e88',1,'Board::CreateLevel(std::string filepath)']]]
];
