#include "Game.hpp"

enum Buttons
{
	MoveLeft = 0,
	MoveRight,
};

Game::Game() {
    window = 0;
    renderer = 0;
}

Game::~Game() {

}

bool Game::Init() {
    SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO);
    TTF_Init();

    // initialize sound/mixer
    Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048);

    // Create window
    window = SDL_CreateWindow("Breakout",
                              SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
                              800, 600, SDL_WINDOW_SHOWN | SDL_WINDOW_OPENGL);
    if (!window) {
        std::cout << "Error creating window:" << SDL_GetError() << std::endl;
        return false;
    }

    // Create renderer
    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
    if (!renderer) {
        printf("Error creating renderer:\n");
        std::cout << "Error creating renderer:" << SDL_GetError() << std::endl;
        return false;
    }

    // initialize sound resources
    brickHitSound = Mix_LoadWAV("Assets/break.wav"); //.wav files are chunks
    ballLostSound = Mix_LoadWAV("Assets/death.wav"); 
    bgmSound = Mix_LoadMUS("Assets/background.mp3"); //mp3 files are music

    // play bgm
    Mix_PlayMusic(bgmSound, -1);
    Mix_VolumeMusic(128);

    level = 0;

    return true;
}

void Game::Clean() {
    delete board;
    delete paddle;
    delete ball;
    delete score;
    delete winlose;
    delete lives;

    // Clean resources
    SDL_DestroyTexture(texture);
    Mix_FreeChunk(brickHitSound);
    Mix_FreeChunk(ballLostSound);

    // Clean renderer and window
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
}

void Game::Run() {
    board = new Board(renderer);
    paddle = new Paddle(renderer);
    ball = new Ball(renderer);

    // Initialize the font
	TTF_Font* font = TTF_OpenFont("Assets/DotGothic16-Regular.ttf", 40);

    //Initialize UI
    score = new UI(10,400, renderer, font);
    winlose = new UI(400, 300, renderer, font);
    lives = new UI(10, 450, renderer, font);
    currLives = 3;
    currScore = 0;

    NewGame();

    float dt = 0.0f;
    int startTime, currentTime, fpsTime = 0;
    int fpsCounter = 0;

    bool buttons[2] = {};
    gameLost = false;
    gameWon = false;
    int totalBricks = GetBrickCount();
    // Main loop
    while (1) {
        if(!gameLost && !gameWon) {
            // Handler events
            SDL_Event e;
            if (SDL_PollEvent(&e)) {
                if (e.type == SDL_QUIT) {
                    break;
                }
                else if(e.type == SDL_KEYDOWN){
                    if(e.key.keysym.sym == SDLK_q || e.key.keysym.sym == SDLK_ESCAPE) {
                        break;
                    }
                    else if(e.key.keysym.sym == SDLK_a || e.key.keysym.sym == SDLK_LEFT) {
                        buttons[Buttons::MoveLeft] = true;

                    }
                    else if(e.key.keysym.sym == SDLK_d || e.key.keysym.sym == SDLK_RIGHT) {
                        buttons[Buttons::MoveRight] = true;

                    }else if(e.key.keysym.sym == SDLK_SPACE && paddlestick) {
                        paddlestick = false;
                        ball->SetDirection(0.1, -1);
                    }
                }
                else if(e.type == SDL_KEYUP) {
                    if(e.key.keysym.sym == SDLK_a || e.key.keysym.sym == SDLK_LEFT) {
                            buttons[Buttons::MoveLeft] = false;

                    }
                    else if(e.key.keysym.sym == SDLK_d || e.key.keysym.sym == SDLK_RIGHT) {
                            buttons[Buttons::MoveRight] = false;
                    }
                }

                if(currScore == totalBricks) {
                    gameWon = true;
                }
                
            }

            //Framerate cap to 60
            startTime = SDL_GetTicks();
            currentTime = startTime;

            if(currentTime - fpsTime <= 16) {
                int elapsedTime = currentTime - fpsTime;
                SDL_Delay(16 - elapsedTime);
                currentTime = SDL_GetTicks();
            }

            fpsTime = currentTime;

            if (buttons[Buttons::MoveLeft])
            {
                //Check if paddle is hitting left border
                if(paddle->x <= board->x) {
                    paddle->SetDirection(0);
                } else {
                    paddle->SetDirection(-1);
                }
                
                
            }
            else if (buttons[Buttons::MoveRight])
            {
                //Check if paddle is hitting right border
                if(paddle->x + paddle->width >= board->x + board->width) {
                    paddle->SetDirection(0);
                } else {
                    paddle->SetDirection(1);
                }
            }
            else 
            {
                //Paddle is not moving
                paddle->SetDirection(0);

            }

            int stopTime = SDL_GetTicks();
            dt = (stopTime - startTime) / 1000.0f;
            
            Update(dt);
            Render();

        } else if(gameLost) {
            char dest[50];
            sprintf(dest, "You Lost :(");
            winlose->SetText(dest);
            Render();
            SDL_Event e;
            if (SDL_PollEvent(&e)) {
                if (e.type == SDL_QUIT) {
                    break;
                }
                else if(e.type == SDL_KEYDOWN){
                    if(e.key.keysym.sym == SDLK_q || e.key.keysym.sym == SDLK_ESCAPE) {
                        break;
                    }
                }
            }
        }else if(gameWon) {
            char dest[50];
            sprintf(dest, "You Won!");
            winlose->SetText(dest);
            //winlose->Draw();
            Render();
            SDL_Event e;
            if (SDL_PollEvent(&e)) {
                if (e.type == SDL_QUIT) {
                    break;
                }
                else if(e.type == SDL_KEYDOWN){
                    if(e.key.keysym.sym == SDLK_q || e.key.keysym.sym == SDLK_ESCAPE) {
                        break;
                    } else if (e.key.keysym.sym == SDLK_SPACE) {
                        //TODO: add 1 to level counter
                        //NewGame or whatever happens
                        level++;
                        NewGame();
                        totalBricks = GetBrickCount();
                    }
                }
            }
        }
    } 

    Clean();

    TTF_Quit();
    Mix_Quit();
    SDL_Quit();
}


void Game::NewGame() {
    gameWon = false;
    gameLost = false;
    currScore = 0;
    currLives = MAX_LIVES;
    winlose->SetText("");
    std::string filepath = levels[level % 4];
    board->CreateLevel(filepath);
    ResetPaddle();
    
}

void Game::ResetPaddle() {
    paddle->x = (board->width / 2) - paddle->width;
    paddlestick = true;
    StickBall();
}

void Game::StickBall() {
    ball->x = paddle->x + paddle->width/2 - ball->width/2;
    ball->y = paddle->y - ball->height;
}

void Game::Update(float delta) {
    // Game logic
    if (paddlestick) {
        StickBall();
    }

    CheckBoardCollisions();
    CheckPaddleCollisions();
    CheckBrickCollisions();

    if (GetBrickCount() == 0) {
        gameWon = true;
    }

    if (currLives <= 0) {
        gameLost = true;
    }

    board->Update(delta);
    paddle->Update(delta);

    if (!paddlestick) {
        ball->Update(delta);
    }
}

void Game::SetPaddleX(float x) {
    float newx;
    if (x < board->x) {
        // Upper bound
        newx = board->x;
    } else if (x + paddle->width > board->x + board->width) {
        // Lower bound
        newx = board->x + board->width - paddle->width;
    } else {
        newx = x;
    }
    paddle->x = newx;
}

void Game::CheckBoardCollisions() {
    // Top and bottom collisions
    if (ball->y < board->y) {
        // Top

        // collision, play sound
        Mix_PlayChannel(-1, brickHitSound, 0);

        // Keep the ball within the board and reflect the y-direction
        ball->y = board->y;
        ball->diry *= -1;
    } else if (ball->y + ball->height > board->y + board->height) {
        // Bottom

        // Ball lost
        // play sound
        Mix_PlayChannel(-1, ballLostSound, 0);

        currLives--;
        ResetPaddle();
    }

    // Left and right collisions
    if (ball->x <= board->x) {
        // Left
        ball->x = board->x;
        ball->dirx *= -1;
        Mix_PlayChannel(-1, brickHitSound, 0);
    } else if (ball->x + ball->width >= board->x + board->width) {
        // Right
        ball->x = board->x + board->width - ball->width;
        ball->dirx *= -1;
        Mix_PlayChannel(-1, brickHitSound, 0);
    }
}

float Game::GetReflection(float hitx) {
    // Make sure the hitx variable is within the width of the paddle
    if (hitx < 0) {
        hitx = 0;
    } else if (hitx > paddle->width) {
        hitx = paddle->width;
    }

    // Everything to the left of the center of the paddle is reflected to the left
    // while everything right of the center is reflected to the right
    hitx -= paddle->width / 2.0f;

    // Scale the reflection, making it fall in the range -2.0f to 2.0f
    return 2.0f * (hitx / (paddle->width / 2.0f));
}


void Game::CheckPaddleCollisions() {
    // Get the center x-coordinate of the ball
    float ballcenterx = ball->x + ball->width / 2.0f;
    // Check paddle collision
    if (ball->Collides(paddle)) {
        //paddle collision, play sound
        Mix_PlayChannel(-1, brickHitSound, 0);

        ball->y = paddle->y - ball->height;
        ball->SetDirection(GetReflection(ballcenterx - paddle->x), -1);
    }
}

void Game::CheckBrickCollisions() {
    for (int i=0; i<BOARD_WIDTH; i++) {
        for (int j=0; j<BOARD_HEIGHT; j++) {
            bool brick = board->bricks[i][j];

            // Check if brick is present
            if (brick) {
                // Brick x and y coordinates
                float brickx = board->brickoffsetx + board->x + i*BOARD_BRWIDTH;
                float bricky = board->brickoffsety + board->y + j*BOARD_BRHEIGHT;

                // Center of the ball x and y coordinates
                float ballcenterx = ball->x + 0.5f*ball->width;
                float ballcentery = ball->y + 0.5f*ball->height;

                // Center of the brick x and y coordinates
                float brickcenterx = brickx + 0.5f*BOARD_BRWIDTH;
                float brickcentery = bricky + 0.5f*BOARD_BRHEIGHT;

                if (ball->x <= brickx + BOARD_BRWIDTH && 
                    ball->x+ball->width >= brickx && 
                    ball->y <= bricky + BOARD_BRHEIGHT && 
                    ball->y + ball->height >= bricky) {
                    // Collision detected, remove the brick
                    board->bricks[i][j] = false;
                    Mix_PlayChannel(-1, brickHitSound, 0);

                    // Calculate ysize
                    float ymin = 0;
                    if (bricky > ball->y) {
                        ymin = bricky;
                    } else {
                        ymin = ball->y;
                    }

                    float ymax = 0;
                    if (bricky+BOARD_BRHEIGHT < ball->y+ball->height) {
                        ymax = bricky+BOARD_BRHEIGHT;
                    } else {
                        ymax = ball->y+ball->height;
                    }

                    float ysize = ymax - ymin;

                    // Calculate xsize
                    float xmin = 0;
                    if (brickx > ball->x) {
                        xmin = brickx;
                    } else {
                        xmin = ball->x;
                    }

                    float xmax = 0;
                    if (brickx+BOARD_BRWIDTH < ball->x+ball->width) {
                        xmax = brickx+BOARD_BRWIDTH;
                    } else {
                        xmax = ball->x+ball->width;
                    }

                    float xsize = xmax - xmin;

                    // The origin is at the top-left corner of the screen!
                    // Set collision response
                    if (xsize > ysize) {
                        if (ballcentery > brickcentery) {
                            // Bottom
                            ball->y += ysize + 0.01f; // Move out of collision
                            BallBrickResponse(3);
                        } else {
                            // Top
                            ball->y -= ysize + 0.01f; // Move out of collision
                            BallBrickResponse(1);
                        }
                    } else {
                        if (ballcenterx < brickcenterx) {
                            // Left
                            ball->x -= xsize + 0.01f; // Move out of collision
                            BallBrickResponse(0);
                        } else {
                            // Right
                            ball->x += xsize + 0.01f; // Move out of collision
                            BallBrickResponse(2);
                        }
                    }
                    currScore++;
                    return;
                }
            }
        }
    }
}

void Game::BallBrickResponse(int dirindex) {
    // dirindex 0: Left, 1: Top, 2: Right, 3: Bottom

    // Direction factors
    int mulx = 1;
    int muly = 1;

    if (ball->dirx > 0) {
        // Ball is moving in the positive x direction
        if (ball->diry > 0) {
            // Ball is moving in the positive y direction
            // +1 +1
            if (dirindex == 0 || dirindex == 3) {
                mulx = -1;
            } else {
                muly = -1;
            }
        } else if (ball->diry < 0) {
            // Ball is moving in the negative y direction
            // +1 -1
            if (dirindex == 0 || dirindex == 1) {
                mulx = -1;
            } else {
                muly = -1;
            }
        }
    } else if (ball->dirx < 0) {
        // Ball is moving in the negative x direction
        if (ball->diry > 0) {
            // Ball is moving in the positive y direction
            // -1 +1
            if (dirindex == 2 || dirindex == 3) {
                mulx = -1;
            } else {
                muly = -1;
            }
        } else if (ball->diry < 0) {
            // Ball is moving in the negative y direction
            // -1 -1
            if (dirindex == 1 || dirindex == 2) {
                mulx = -1;
            } else {
                muly = -1;
            }
        }
    }

    // Set the new direction of the ball, by multiplying the old direction
    // with the determined direction factors
    ball->SetDirection(mulx*ball->dirx, muly*ball->diry);
}

int Game::GetBrickCount() {
    int brickcount = 0;
    for (int i=0; i<BOARD_WIDTH; i++) {
        for (int j=0; j<BOARD_HEIGHT; j++) {
            bool brick = board->bricks[i][j];
            if (brick) {
                brickcount++;
            }
        }
    }

    return brickcount;
}

void Game::Render() {
    SDL_RenderClear(renderer);

    board->Render();
    paddle->Render();
    ball->Render();

    char dest[50];

    sprintf(dest, "Score: %i", currScore);
    score->SetText(dest);
    score->Render();

    sprintf(dest, "Lives: %i", currLives);
    lives->SetText(dest);
    lives->Render();

    winlose->Render();

    SDL_RenderPresent(renderer);
}
