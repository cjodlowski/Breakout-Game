#include "UI.hpp"

UI::UI(float x, float y, SDL_Renderer* renderer, TTF_Font* font) : renderer(renderer){
    this->font = font;
    surface = TTF_RenderText_Solid(font, " ", {0xFF, 0xFF, 0xFF, 0xFF});
    texture = SDL_CreateTextureFromSurface(renderer, surface);
    
	SDL_QueryTexture(texture, nullptr, nullptr, &width, &height);

    rect.x = static_cast<int>(x);
    rect.y = static_cast<int>(y);
    rect.w = width;
    rect.h = height;
}

UI::~UI()
{
    SDL_FreeSurface(surface);
    SDL_DestroyTexture(texture);
}

void UI::Update(float dt) {

}

void UI::Render()
{
    SDL_RenderCopy(renderer, texture, nullptr, &rect);
}

void UI::SetText(char * text)
{
    SDL_FreeSurface(surface);
    SDL_DestroyTexture(texture);

    surface = TTF_RenderText_Solid(font, text, {0xFF, 0xFF, 0xFF, 0xFF});
    texture = SDL_CreateTextureFromSurface(renderer, surface);

    SDL_QueryTexture(texture, nullptr, nullptr, &width, &height);
    rect.w = width;
    rect.h = height;
}