#ifndef BOARD_H_
#define BOARD_H_

#include "Entity.hpp"
#include <stdlib.h>
#include <time.h>
#include <iostream>
#include <fstream>
#include <string>

// Define the dimensions of the board and bricks
#define BOARD_WIDTH 12
#define BOARD_HEIGHT 12
#define BOARD_BRWIDTH 64
#define BOARD_BRHEIGHT 24

/**
 * Class Representing the board for each level.
 * It contains an 2D array of booleans that determine
 * where bricks are located on the board.
*/
class Board: public Entity {
public:
    /**
     * Constructor for the Board that takes in a pointer
     * to the Game's SDL_Renderer.
    **/
    Board(SDL_Renderer* renderer);
    /**
     * Destructor that frees the brick and side textures
     * and then deletes the board.
    **/
    ~Board();

    float brickoffsetx, brickoffsety;
    bool bricks[BOARD_WIDTH][BOARD_HEIGHT];

    /**
     * Updates the boards position.
     * Should be empty/ not do anything, since the board does not move.
     * Can be updated to have the board move, if you want it to.
    */
    void Update(float delta);
    /**
     * Renders the board.
     * Renders each brick if the boolean value at its position is true.
    */
    void Render();
    /**
     * Default method for creating a level.
     * Sets all brick values to true.
    */
    void CreateLevel();

    /**
     * Creates a level from a text file at a given file path.
     * The text file should be 12 lines long, with each line having 12
     * characters to create a 12x12 board. 1s indicate that a brick is
     * present, while 0s represent an empty space.
     * If the file cannot be found, this method will call the default
     * CreateLevel(), setting all bricks to be present.
    */
    void CreateLevel(std::string filepath);

private:
    SDL_Texture* bricktexture;
    SDL_Texture* sidetexture;
};

#endif