#ifndef PADDLE_H_
#define PADDLE_H_

#include "Entity.hpp"

const float PADDLE_SPEED = 550;

/**
 * Class representing the Player paddle.
 * The player can move side to side.
*/
class Paddle: public Entity {
public:
    /**
     * Constructor for Paddle that uses the renderer from Game.
    */
    Paddle(SDL_Renderer* renderer);
    /**
     * Destructor for the paddle that frees the texture it is using.
    */
    ~Paddle();

    float dirx;

    /**
     * Updates the position of the player based on the calculated 
     * delta time value and the current direction.
    */
    void Update(float delta);

    /**
     * Renders the paddle at its given position.
    */
    void Render();
    /**
     * Sets the direction of the paddle.
     * dirx should usually be 0,1, or -1.
     * There is no diry because the player can only move horizontally.
    **/
    void SetDirection(float dirx);

private:
    SDL_Texture* texture;
};

#endif
