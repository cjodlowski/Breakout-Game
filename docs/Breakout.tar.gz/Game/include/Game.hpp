#ifndef GAME_H_
#define GAME_H_

#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_mixer.h>
#include <iostream>
#include <stdio.h>
#include <string>

#include "Board.hpp"
#include "Paddle.hpp"
#include "Ball.hpp"
#include "UI.hpp"

#define MAX_LIVES 3;

/**
 * The class representing the entire Game.
 * Should only be inititalized once within the code.
 * It is not a singleton class but main only calls it once.
**/
class Game {
public:
    /** 
     * Creates a new Game.
    */
    Game();
    /**
     * Destructor for the Game class.
    */
    ~Game();

    /**
     * Initializes variables for the game.
    */
    bool Init();
    /**
     * Runs the main while loop for the game.
    */
    void Run();

private:
    //Main Window and Renderer
    SDL_Window* window;
    SDL_Renderer* renderer;
    SDL_Texture* texture;

    // sounds
    Mix_Chunk* brickHitSound;
    Mix_Chunk* ballLostSound;
    Mix_Music* bgmSound;

    //Levels
    std::string levels[4] = {"Assets/level1.txt", "Assets/level2.txt", "Assets/level3.txt", "Assets/level4.txt"};
    unsigned int level;

    //Entities
    Board* board;
    Paddle* paddle;
    Ball* ball;
    bool paddlestick;

    //UI
    UI* score;
    UI* winlose;
    UI* lives;
    int currScore;
    int currLives;

    //To check if game was won or lost
    bool gameWon;
    bool gameLost;

    /**
     * Frees the  memory of all allocated variables
    */
    void Clean();

    /**
     * Updates positions of all entities within the game.
    */
    void Update(float delta);

    /**
     * Renders all entities within the game.
     * Moves the renderer to the background
     * and then to the foreground after calling Render on all entities
    */
    void Render();

    /**
     * Loads the next level of the Game.
     * Resets the score to zero and sets the
     * amount of lives remianing to defined max.
    */
    void NewGame();

    /**
     * Resets the paddle to the bottom middle of the screen.
     * Sets paddlestick to true so the ball sticks to the paddle
     * at the start of each life.
    */
    void ResetPaddle();

    /**
     * Keeps the balls position slightly above the middle of the paddle.
    */
    void StickBall();

    /**
     * Directly sets the paddle's position to the given x.
     * Used when the game resets, not for player controls.
     * Most of this function was written from the tutorial http://rembound.com/articles/the-breakout-tutorial.
    */
    void SetPaddleX(float x);
    /**
     * Checks if the ball hits the top or side borders of the window.
     * If the ball's position is below the paddle, this method
     * subtracts the number of lives the player has remaining and resets the paddle.
     * Most of this function was written from the tutorial http://rembound.com/articles/the-breakout-tutorial.
    */
    void CheckBoardCollisions();
    /**
     * Returns the x direction the ball should be headed after a collision.
     * Most of this function was written from the tutorial http://rembound.com/articles/the-breakout-tutorial.
    */
    float GetReflection(float hitx);
    /**
     * Checks if the ball collided with the paddle.
     * Reflects the direction of the ball if there was a collision.
     * Most of this function was written from the tutorial http://rembound.com/articles/the-breakout-tutorial.
    */
    void CheckPaddleCollisions();
    /**
    * Cycles through all rendered bricks to see if the
     * ball is in within any of their rectangles.
     * Reflects the ball's direction and destroys the brick if there was a collision.
     * Most of this function was written from the tutorial http://rembound.com/articles/the-breakout-tutorial.
    */
    void CheckBrickCollisions();
    /**
     * Calculates which direction the ball should be reflected.
     * Direction determined by whether the ball hit the top, bottom, left, or right
     * side of the brick.
     * Most of this function was written from the tutorial http://rembound.com/articles/the-breakout-tutorial.
    */ 
    void BallBrickResponse(int dirindex);
    /**
     * Returns the amount of bricks remaining on the board.
     * Most of this function was written from the tutorial http://rembound.com/articles/the-breakout-tutorial.
    */ 
    int GetBrickCount();
};

#endif
