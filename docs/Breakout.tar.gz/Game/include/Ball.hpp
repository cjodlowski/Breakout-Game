#ifndef BALL_H_
#define BALL_H_

#include "Entity.hpp"

#include <math.h>

// Define a ball speed in pixels per second
const float BALL_SPEED = 500;

/**
 * A class representing the Ball in breakout.
 * Ball inherits the Entity class and is able to
 * interact with the Board, Bricks, and Paddle.
 * The Ball is given a set speed as a constant.
*/
class Ball: public Entity {
public:
    /**
     * Creates a ball from the Game's renderer.
    */
    Ball(SDL_Renderer* renderer);
    /**
     * Deconstructor for ball. Frees memory allocated from
     * the generated Texture
    **/
    ~Ball();

    float dirx, diry;
    /**
     * Updates the balls position based its current dirx, diry
     * values and the calculated time delta value.
    */
    void Update(float delta);

    /**
     * Renders the ball at its current position using the loaded
     * SDL Texture.
    **/
    void Render();

    /**
     * Sets the direction of the ball to the given dirx and diry
     * values. Mainly used for setting reflections.
    **/
    void SetDirection(float dirx, float diry);
private:
    SDL_Texture* texture;

};

#endif
