#ifndef UI_H_
#define UI_H_

#include <string.h>
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_ttf.h>

/**
 * Class that represents all TextUI in the game.
 * Used for lives, score, and win/lose UI.
*/
class UI {
    public:
        /**
         * Constructor for UI  that takes in the position it should be located,
         * the Game's renderer, and what font should be used.
        */
        UI(float x, float y, SDL_Renderer* renderer, TTF_Font* font);
        /**
         * Destructor that frees the surfaces and textures used by the UI.
         */
        ~UI();

        /**
         * Inherited method from Entity.
         * Should be empty as the UI does not move during the Game.
        */
        void Update(float dt);

        /**
         * Renders the text at the UI's given position.
        */
        void Render();

        /**
         * Sets what text should be displayed for this piece of UI.
        */
        void SetText(char * text);
    private:
        SDL_Renderer* renderer;
		TTF_Font* font;
		SDL_Surface* surface;
		SDL_Texture* texture;
		SDL_Rect rect;

        float x, y;
        int width, height;
        char * text;
};


#endif