
#ifndef ENTITY_H_
#define ENTITY_H_

#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>

/**
 * An abstract class menat to define all interactable physics objects within the game.
 *  The Entity class keeps track of a pointer to a renderer as well as public position
 * and width/height values for the renderer.
*/
class Entity {
public:
    /**
     * Superclass constructor that takes in a pointer to a renderer.
     * Renderer should be provided by the Game class
    */
    Entity(SDL_Renderer* renderer);
    /**
     * Virtual destructor, should never be called.
     * Destructors should be handled by inheriting class.
    */
    virtual ~Entity();

    float x, y, width, height;

    /**
     * Updates the position and direction for each entity.
     * Should only be used for objects that are moving, such
     * as the Ball and Paddle, and can be left empty for stationary
     * objects.
    */
    virtual void Update(float delta);

    /**
     * Renders the object at its (x,y) position and its given
     * width and height. Width and height are usually determined
     * by the surface and texture generated from a given .png file
     * or TTF_Font.
    */
    virtual void Render();

    /**
     * Checks if this Entity is colliding with another entity.
     * Collisions are detected by calculating the half of the 
     * width and height from the (x,y) position.
    */
    bool Collides(Entity* other);
protected:
    SDL_Renderer* renderer;

};

#endif
